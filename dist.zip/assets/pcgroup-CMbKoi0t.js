const o="/assets/pcgroup-BC5wOXtD.png";export{o as l};
