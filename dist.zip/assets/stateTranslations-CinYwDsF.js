const o={Bot:"ChatBot",Waiting:"En espera",Human:"Asignado",Closed:"Cerrado",Incomplete:"Incompleto"};export{o as s};
